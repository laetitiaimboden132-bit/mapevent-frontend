"""
Backend Flask pour MapEventAI
API REST pour gérer les événements, bookings et services
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import psycopg2
import redis
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional

# Configuration du logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_app():
    """Crée et configure l'application Flask"""
    app = Flask(__name__)
    CORS(app)  # Permettre les requêtes cross-origin
    
    # Configuration depuis les variables d'environnement
    app.config['RDS_HOST'] = os.getenv('RDS_HOST', '')
    app.config['RDS_PORT'] = os.getenv('RDS_PORT', '5432')
    app.config['RDS_DB'] = os.getenv('RDS_DB', 'mapevent')
    app.config['RDS_USER'] = os.getenv('RDS_USER', '')
    app.config['RDS_PASSWORD'] = os.getenv('RDS_PASSWORD', '')
    
    app.config['REDIS_HOST'] = os.getenv('REDIS_HOST', '')
    app.config['REDIS_PORT'] = os.getenv('REDIS_PORT', '6379')
    
    # Connexions
    def get_db_connection():
        """Crée une connexion à PostgreSQL"""
        try:
            # Nettoyer le nom de la base de données (enlever les espaces)
            db_name = app.config['RDS_DB'].strip()
            print(f"Tentative de connexion à RDS: {app.config['RDS_HOST']}:{app.config['RDS_PORT']}/{db_name}")
            print(f"User: {app.config['RDS_USER']}")
            print(f"Password length: {len(app.config['RDS_PASSWORD']) if app.config['RDS_PASSWORD'] else 0}")
            conn = psycopg2.connect(
                host=app.config['RDS_HOST'],
                port=app.config['RDS_PORT'],
                database=db_name,
                user=app.config['RDS_USER'],
                password=app.config['RDS_PASSWORD'],
                connect_timeout=10,
                sslmode='require'  # RDS nécessite SSL
            )
            print("✅ Connexion RDS réussie")
            return conn
        except Exception as e:
            error_msg = f"❌ Erreur connexion DB: {e}"
            print(error_msg)
            logger.error(error_msg)
            import traceback
            print(traceback.format_exc())
            return None
    
    def get_redis_connection():
        """Crée une connexion à Redis"""
        try:
            r = redis.Redis(
                host=app.config['REDIS_HOST'],
                port=int(app.config['REDIS_PORT']),
                decode_responses=True
            )
            r.ping()  # Tester la connexion
            return r
        except Exception as e:
            logger.error(f"Erreur connexion Redis: {e}")
            return None
    
    # Routes API
    
    @app.route('/api/health', methods=['GET'])
    def health():
        """Vérification de santé de l'API"""
        return jsonify({
            'status': 'ok',
            'timestamp': datetime.utcnow().isoformat()
        })
    
    @app.route('/api/events', methods=['GET'])
    def get_events():
        """Récupère tous les événements"""
        try:
            print("🔍 Appel à /api/events")
            conn = get_db_connection()
            if not conn:
                print("❌ get_db_connection() a retourné None")
                return jsonify({'error': 'Database connection failed'}), 500
            
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, title, description, location, latitude, longitude, 
                       date, time, categories, created_at
                FROM events
                ORDER BY created_at DESC
            """)
            
            events = []
            for row in cursor.fetchall():
                try:
                    # Gérer les catégories (peuvent être JSON string, list, ou None)
                    categories = []
                    if row[8]:
                        if isinstance(row[8], list):
                            categories = row[8]
                        elif isinstance(row[8], str):
                            try:
                                categories = json.loads(row[8])
                            except (json.JSONDecodeError, TypeError):
                                categories = []
                    
                    events.append({
                        'id': row[0],
                        'title': row[1] or '',
                        'description': row[2] or '',
                        'location': row[3] or '',
                        'latitude': float(row[4]) if row[4] is not None else None,
                        'longitude': float(row[5]) if row[5] is not None else None,
                        'date': row[6].isoformat() if row[6] else None,
                        'time': str(row[7]) if row[7] else None,
                        'categories': categories,
                        'created_at': row[9].isoformat() if row[9] else None
                    })
                except Exception as row_error:
                    print(f"❌ Erreur traitement ligne: {row_error}")
                    logger.error(f"Erreur traitement ligne: {row_error}")
                    continue
            
            cursor.close()
            conn.close()
            
            print(f"✅ {len(events)} événements récupérés")
            return jsonify(events)
        except Exception as e:
            error_msg = f"❌ Erreur get_events: {e}"
            print(error_msg)
            logger.error(error_msg)
            import traceback
            print(traceback.format_exc())
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/events/publish', methods=['POST'])
    def publish_event():
        """Publie un nouvel événement"""
        try:
            data = request.get_json()
            
            # Validation
            required_fields = ['title', 'location', 'latitude', 'longitude']
            for field in required_fields:
                if field not in data:
                    return jsonify({'error': f'Missing field: {field}'}), 400
            
            conn = get_db_connection()
            if not conn:
                return jsonify({'error': 'Database connection failed'}), 500
            
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO events (title, description, location, latitude, longitude, 
                                  date, time, categories, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id
            """, (
                data.get('title'),
                data.get('description', ''),
                data.get('location'),
                float(data.get('latitude')),
                float(data.get('longitude')),
                data.get('date'),
                data.get('time'),
                json.dumps(data.get('categories', [])),
                datetime.utcnow()
            ))
            
            event_id = cursor.fetchone()[0]
            conn.commit()
            cursor.close()
            conn.close()
            
            # Invalider le cache Redis
            redis_conn = get_redis_connection()
            if redis_conn:
                redis_conn.delete('events:all')
            
            return jsonify({'id': event_id, 'status': 'published'}), 201
        except Exception as e:
            logger.error(f"Erreur publish_event: {e}")
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/bookings', methods=['GET'])
    def get_bookings():
        """Récupère tous les bookings"""
        try:
            conn = get_db_connection()
            if not conn:
                return jsonify({'error': 'Database connection failed'}), 500
            
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, name, description, location, latitude, longitude, 
                       categories, created_at
                FROM bookings
                ORDER BY created_at DESC
            """)
            
            bookings = []
            for row in cursor.fetchall():
                bookings.append({
                    'id': row[0],
                    'name': row[1],
                    'description': row[2],
                    'location': row[3],
                    'latitude': float(row[4]) if row[4] else None,
                    'longitude': float(row[5]) if row[5] else None,
                    'categories': row[6] if isinstance(row[6], list) else json.loads(row[6]) if row[6] else [],
                    'created_at': row[7].isoformat() if row[7] else None
                })
            
            cursor.close()
            conn.close()
            
            return jsonify(bookings)
        except Exception as e:
            logger.error(f"Erreur get_bookings: {e}")
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/bookings/publish', methods=['POST'])
    def publish_booking():
        """Publie un nouveau booking"""
        try:
            data = request.get_json()
            
            # Validation
            required_fields = ['name', 'location', 'latitude', 'longitude']
            for field in required_fields:
                if field not in data:
                    return jsonify({'error': f'Missing field: {field}'}), 400
            
            conn = get_db_connection()
            if not conn:
                return jsonify({'error': 'Database connection failed'}), 500
            
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO bookings (name, description, location, latitude, longitude, 
                                     categories, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                RETURNING id
            """, (
                data.get('name'),
                data.get('description', ''),
                data.get('location'),
                float(data.get('latitude')),
                float(data.get('longitude')),
                json.dumps(data.get('categories', [])),
                datetime.utcnow()
            ))
            
            booking_id = cursor.fetchone()[0]
            conn.commit()
            cursor.close()
            conn.close()
            
            # Invalider le cache Redis
            redis_conn = get_redis_connection()
            if redis_conn:
                redis_conn.delete('bookings:all')
            
            return jsonify({'id': booking_id, 'status': 'published'}), 201
        except Exception as e:
            logger.error(f"Erreur publish_booking: {e}")
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/services', methods=['GET'])
    def get_services():
        """Récupère tous les services"""
        try:
            conn = get_db_connection()
            if not conn:
                return jsonify({'error': 'Database connection failed'}), 500
            
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, name, description, location, latitude, longitude, 
                       categories, created_at
                FROM services
                ORDER BY created_at DESC
            """)
            
            services = []
            for row in cursor.fetchall():
                services.append({
                    'id': row[0],
                    'name': row[1],
                    'description': row[2],
                    'location': row[3],
                    'latitude': float(row[4]) if row[4] else None,
                    'longitude': float(row[5]) if row[5] else None,
                    'categories': row[6] if isinstance(row[6], list) else json.loads(row[6]) if row[6] else [],
                    'created_at': row[7].isoformat() if row[7] else None
                })
            
            cursor.close()
            conn.close()
            
            return jsonify(services)
        except Exception as e:
            logger.error(f"Erreur get_services: {e}")
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/services/publish', methods=['POST'])
    def publish_service():
        """Publie un nouveau service"""
        try:
            data = request.get_json()
            
            # Validation
            required_fields = ['name', 'location', 'latitude', 'longitude']
            for field in required_fields:
                if field not in data:
                    return jsonify({'error': f'Missing field: {field}'}), 400
            
            conn = get_db_connection()
            if not conn:
                return jsonify({'error': 'Database connection failed'}), 500
            
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO services (name, description, location, latitude, longitude, 
                                     categories, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                RETURNING id
            """, (
                data.get('name'),
                data.get('description', ''),
                data.get('location'),
                float(data.get('latitude')),
                float(data.get('longitude')),
                json.dumps(data.get('categories', [])),
                datetime.utcnow()
            ))
            
            service_id = cursor.fetchone()[0]
            conn.commit()
            cursor.close()
            conn.close()
            
            # Invalider le cache Redis
            redis_conn = get_redis_connection()
            if redis_conn:
                redis_conn.delete('services:all')
            
            return jsonify({'id': service_id, 'status': 'published'}), 201
        except Exception as e:
            logger.error(f"Erreur publish_service: {e}")
            return jsonify({'error': str(e)}), 500
    
    # Routes utilisateur
    @app.route('/api/user/likes', methods=['POST'])
    def user_likes():
        """Gère les likes des utilisateurs pour les événements, bookings et services."""
        try:
            data = request.get_json()
            user_id = data.get('userId')
            item_id = data.get('itemId')
            item_type = data.get('itemMode')
            action = data.get('action') # 'add' or 'remove'

            if not all([user_id, item_id, item_type, action]):
                return jsonify({'error': 'Missing required fields'}), 400

            conn = get_db_connection()
            if not conn:
                return jsonify({'error': 'Database connection failed'}), 500
            cursor = conn.cursor()

            # Assurer que l'utilisateur existe (ou le créer si c'est la première action)
            cursor.execute("INSERT INTO users (id) VALUES (%s) ON CONFLICT (id) DO NOTHING", (user_id,))
            conn.commit()

            if action == 'add':
                cursor.execute(
                    "INSERT INTO user_likes (user_id, item_type, item_id) VALUES (%s, %s, %s) ON CONFLICT (user_id, item_type, item_id) DO NOTHING",
                    (user_id, item_type, item_id)
                )
                conn.commit()
                cursor.close()
                conn.close()
                return jsonify({'success': True, 'action': 'added'}), 200
            elif action == 'remove':
                cursor.execute(
                    "DELETE FROM user_likes WHERE user_id = %s AND item_type = %s AND item_id = %s",
                    (user_id, item_type, item_id)
                )
                conn.commit()
                cursor.close()
                conn.close()
                return jsonify({'success': True, 'action': 'removed'}), 200
            else:
                return jsonify({'error': 'Invalid action'}), 400
        except Exception as e:
            logger.error(f"Erreur user_likes: {e}")
            return jsonify({'error': str(e)}), 500

    @app.route('/api/user/favorites', methods=['POST'])
    def user_favorites():
        """Gère les favoris des utilisateurs."""
        try:
            data = request.get_json()
            user_id = data.get('userId')
            item_id = data.get('itemId')
            item_type = data.get('itemMode')
            action = data.get('action') # 'add' or 'remove'

            if not all([user_id, item_id, item_type, action]):
                return jsonify({'error': 'Missing required fields'}), 400

            conn = get_db_connection()
            if not conn:
                return jsonify({'error': 'Database connection failed'}), 500
            cursor = conn.cursor()

            cursor.execute("INSERT INTO users (id) VALUES (%s) ON CONFLICT (id) DO NOTHING", (user_id,))
            conn.commit()

            if action == 'add':
                cursor.execute(
                    "INSERT INTO user_favorites (user_id, item_type, item_id) VALUES (%s, %s, %s) ON CONFLICT (user_id, item_type, item_id) DO NOTHING",
                    (user_id, item_type, item_id)
                )
                conn.commit()
                cursor.close()
                conn.close()
                return jsonify({'success': True, 'action': 'added'}), 200
            elif action == 'remove':
                cursor.execute(
                    "DELETE FROM user_favorites WHERE user_id = %s AND item_type = %s AND item_id = %s",
                    (user_id, item_type, item_id)
                )
                conn.commit()
                cursor.close()
                conn.close()
                return jsonify({'success': True, 'action': 'removed'}), 200
            else:
                return jsonify({'error': 'Invalid action'}), 400
        except Exception as e:
            logger.error(f"Erreur user_favorites: {e}")
            return jsonify({'error': str(e)}), 500

    @app.route('/api/user/participate', methods=['POST'])
    def user_participate():
        """Gère la participation des utilisateurs aux événements."""
        try:
            data = request.get_json()
            user_id = data.get('userId')
            item_id = data.get('itemId')
            item_type = data.get('itemMode') # Principalement 'event'
            action = data.get('action') # 'add' or 'remove'

            if not all([user_id, item_id, item_type, action]):
                return jsonify({'error': 'Missing required fields'}), 400

            conn = get_db_connection()
            if not conn:
                return jsonify({'error': 'Database connection failed'}), 500
            cursor = conn.cursor()

            cursor.execute("INSERT INTO users (id) VALUES (%s) ON CONFLICT (id) DO NOTHING", (user_id,))
            conn.commit()

            if action == 'add':
                cursor.execute(
                    "INSERT INTO user_participations (user_id, item_type, item_id) VALUES (%s, %s, %s) ON CONFLICT (user_id, item_type, item_id) DO NOTHING",
                    (user_id, item_type, item_id)
                )
                conn.commit()
                cursor.close()
                conn.close()
                return jsonify({'success': True, 'action': 'added'}), 200
            elif action == 'remove':
                cursor.execute(
                    "DELETE FROM user_participations WHERE user_id = %s AND item_type = %s AND item_id = %s",
                    (user_id, item_type, item_id)
                )
                conn.commit()
                cursor.close()
                conn.close()
                return jsonify({'success': True, 'action': 'removed'}), 200
            else:
                return jsonify({'error': 'Invalid action'}), 400
        except Exception as e:
            logger.error(f"Erreur user_participate: {e}")
            return jsonify({'error': str(e)}), 500

    @app.route('/api/user/agenda', methods=['POST'])
    def user_agenda():
        """Gère l'ajout/retrait d'éléments à l'agenda de l'utilisateur."""
        try:
            data = request.get_json()
            user_id = data.get('userId')
            item_id = data.get('itemId')
            item_type = data.get('itemMode')
            action = data.get('action') # 'add' or 'remove'

            if not all([user_id, item_id, item_type, action]):
                return jsonify({'error': 'Missing required fields'}), 400

            conn = get_db_connection()
            if not conn:
                return jsonify({'error': 'Database connection failed'}), 500
            cursor = conn.cursor()

            cursor.execute("INSERT INTO users (id) VALUES (%s) ON CONFLICT (id) DO NOTHING", (user_id,))
            conn.commit()

            if action == 'add':
                cursor.execute(
                    "INSERT INTO user_agenda (user_id, item_type, item_id) VALUES (%s, %s, %s) ON CONFLICT (user_id, item_type, item_id) DO NOTHING",
                    (user_id, item_type, item_id)
                )
                conn.commit()
                cursor.close()
                conn.close()
                return jsonify({'success': True, 'action': 'added'}), 200
            elif action == 'remove':
                cursor.execute(
                    "DELETE FROM user_agenda WHERE user_id = %s AND item_type = %s AND item_id = %s",
                    (user_id, item_type, item_id)
                )
                conn.commit()
                cursor.close()
                conn.close()
                return jsonify({'success': True, 'action': 'removed'}), 200
            else:
                return jsonify({'error': 'Invalid action'}), 400
        except Exception as e:
            logger.error(f"Erreur user_agenda: {e}")
            return jsonify({'error': str(e)}), 500
    
    # Routes d'administration temporaires (À SUPPRIMER APRÈS UTILISATION)
    try:
        from admin_routes import create_admin_routes
        create_admin_routes(app)
        logger.info("Routes d'administration chargées")
    except ImportError:
        logger.warning("admin_routes non disponible")
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)




