-- ============================================
-- Schéma de base de données pour MapEventAI
-- ============================================

-- Table des événements
CREATE TABLE IF NOT EXISTS events (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    location VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    date DATE,
    time TIME,
    categories JSONB DEFAULT '[]'::jsonb,
    likes_count INTEGER DEFAULT 0,
    favorites_count INTEGER DEFAULT 0,
    participations_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des bookings (hébergements)
CREATE TABLE IF NOT EXISTS bookings (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    location VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    categories JSONB DEFAULT '[]'::jsonb,
    likes_count INTEGER DEFAULT 0,
    favorites_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des services
CREATE TABLE IF NOT EXISTS services (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    location VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    categories JSONB DEFAULT '[]'::jsonb,
    likes_count INTEGER DEFAULT 0,
    favorites_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des utilisateurs (pour les actions)
-- Note: Pour l'instant, on utilise un système simple avec user_id comme string
-- Plus tard, on pourra créer une vraie table users avec authentification
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(255) PRIMARY KEY,
    email VARCHAR(255) UNIQUE,
    username VARCHAR(255),
    subscription VARCHAR(50) DEFAULT 'free',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des likes (likes sur events, bookings, services)
CREATE TABLE IF NOT EXISTS user_likes (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    item_type VARCHAR(50) NOT NULL, -- 'event', 'booking', 'service'
    item_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, item_type, item_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_user_likes_user ON user_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_user_likes_item ON user_likes(item_type, item_id);

-- Table des favoris
CREATE TABLE IF NOT EXISTS user_favorites (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    item_type VARCHAR(50) NOT NULL, -- 'event', 'booking', 'service'
    item_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, item_type, item_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_user_favorites_user ON user_favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_user_favorites_item ON user_favorites(item_type, item_id);

-- Table des participations (inscriptions aux événements)
CREATE TABLE IF NOT EXISTS user_participations (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    item_type VARCHAR(50) NOT NULL, -- 'event' principalement
    item_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, item_type, item_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_user_participations_user ON user_participations(user_id);
CREATE INDEX IF NOT EXISTS idx_user_participations_item ON user_participations(item_type, item_id);

-- Table de l'agenda (événements ajoutés à l'agenda)
CREATE TABLE IF NOT EXISTS user_agenda (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    item_type VARCHAR(50) NOT NULL, -- 'event', 'booking', 'service'
    item_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, item_type, item_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_user_agenda_user ON user_agenda(user_id);
CREATE INDEX IF NOT EXISTS idx_user_agenda_item ON user_agenda(item_type, item_id);

-- Table des avis/commentaires (pour plus tard)
CREATE TABLE IF NOT EXISTS user_reviews (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    item_type VARCHAR(50) NOT NULL, -- 'event', 'booking', 'service'
    item_id INTEGER NOT NULL,
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_user_reviews_item ON user_reviews(item_type, item_id);

-- Table des signalements (pour plus tard)
CREATE TABLE IF NOT EXISTS user_reports (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    item_type VARCHAR(50) NOT NULL, -- 'event', 'booking', 'service'
    item_id INTEGER NOT NULL,
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Table des discussions/messages (pour plus tard)
CREATE TABLE IF NOT EXISTS discussions (
    id SERIAL PRIMARY KEY,
    item_type VARCHAR(50) NOT NULL, -- 'event', 'booking', 'service'
    item_id INTEGER NOT NULL,
    user_id VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_discussions_item ON discussions(item_type, item_id);

-- Fonction pour mettre à jour updated_at automatiquement
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers pour mettre à jour updated_at
DROP TRIGGER IF EXISTS update_events_updated_at ON events;
CREATE TRIGGER update_events_updated_at BEFORE UPDATE ON events
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_bookings_updated_at ON bookings;
CREATE TRIGGER update_bookings_updated_at BEFORE UPDATE ON bookings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_services_updated_at ON services;
CREATE TRIGGER update_services_updated_at BEFORE UPDATE ON services
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_users_updated_at ON users;
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_user_reviews_updated_at ON user_reviews;
CREATE TRIGGER update_user_reviews_updated_at BEFORE UPDATE ON user_reviews
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Fonctions pour mettre à jour les compteurs (likes, favorites, participations)
CREATE OR REPLACE FUNCTION update_likes_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.item_type = 'event' THEN
            UPDATE events SET likes_count = likes_count + 1 WHERE id = NEW.item_id;
        ELSIF NEW.item_type = 'booking' THEN
            UPDATE bookings SET likes_count = likes_count + 1 WHERE id = NEW.item_id;
        ELSIF NEW.item_type = 'service' THEN
            UPDATE services SET likes_count = likes_count + 1 WHERE id = NEW.item_id;
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        IF OLD.item_type = 'event' THEN
            UPDATE events SET likes_count = GREATEST(likes_count - 1, 0) WHERE id = OLD.item_id;
        ELSIF OLD.item_type = 'booking' THEN
            UPDATE bookings SET likes_count = GREATEST(likes_count - 1, 0) WHERE id = OLD.item_id;
        ELSIF OLD.item_type = 'service' THEN
            UPDATE services SET likes_count = GREATEST(likes_count - 1, 0) WHERE id = OLD.item_id;
        END IF;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS trigger_update_likes_count ON user_likes;
CREATE TRIGGER trigger_update_likes_count
    AFTER INSERT OR DELETE ON user_likes
    FOR EACH ROW EXECUTE FUNCTION update_likes_count();

CREATE OR REPLACE FUNCTION update_favorites_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.item_type = 'event' THEN
            UPDATE events SET favorites_count = favorites_count + 1 WHERE id = NEW.item_id;
        ELSIF NEW.item_type = 'booking' THEN
            UPDATE bookings SET favorites_count = favorites_count + 1 WHERE id = NEW.item_id;
        ELSIF NEW.item_type = 'service' THEN
            UPDATE services SET favorites_count = favorites_count + 1 WHERE id = NEW.item_id;
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        IF OLD.item_type = 'event' THEN
            UPDATE events SET favorites_count = GREATEST(favorites_count - 1, 0) WHERE id = OLD.item_id;
        ELSIF OLD.item_type = 'booking' THEN
            UPDATE bookings SET favorites_count = GREATEST(favorites_count - 1, 0) WHERE id = OLD.item_id;
        ELSIF OLD.item_type = 'service' THEN
            UPDATE services SET favorites_count = GREATEST(favorites_count - 1, 0) WHERE id = OLD.item_id;
        END IF;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS trigger_update_favorites_count ON user_favorites;
CREATE TRIGGER trigger_update_favorites_count
    AFTER INSERT OR DELETE ON user_favorites
    FOR EACH ROW EXECUTE FUNCTION update_favorites_count();

CREATE OR REPLACE FUNCTION update_participations_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.item_type = 'event' THEN
            UPDATE events SET participations_count = participations_count + 1 WHERE id = NEW.item_id;
        END IF;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        IF OLD.item_type = 'event' THEN
            UPDATE events SET participations_count = GREATEST(participations_count - 1, 0) WHERE id = OLD.item_id;
        END IF;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS trigger_update_participations_count ON user_participations;
CREATE TRIGGER trigger_update_participations_count
    AFTER INSERT OR DELETE ON user_participations
    FOR EACH ROW EXECUTE FUNCTION update_participations_count();


