"""
Lambda Handler pour MapEventAI Backend
Handler simple avec Flask test client - version ultra-simplifiée
"""

import sys
import json
from pathlib import Path

# Ajouter le chemin du backend au PYTHONPATH
backend_path = Path(__file__).parent / "backend"
backend_path_str = str(backend_path.resolve())
if backend_path_str not in sys.path:
    sys.path.insert(0, backend_path_str)

# Importer la fonction de création de l'app Flask (mais ne pas créer l'app maintenant)
try:
    from main import create_app
except ImportError as e:
    print(f"Import error: {e}")
    print(f"Python path: {sys.path}")
    # Ne pas lever l'erreur ici, on gérera OPTIONS même sans Flask

# Variable globale pour l'app Flask (créée à la demande)
app = None

def lambda_handler(event, context):
    """
    Handler Lambda pour API Gateway
    Version ultra-simplifiée avec Flask test client
    """
    # Gérer OPTIONS AVANT TOUT, même avant de créer l'app Flask
    try:
        method = event.get('httpMethod', event.get('requestContext', {}).get('http', {}).get('method', 'GET'))
        
        if method == 'OPTIONS':
            print(f"OK: Requete OPTIONS detectee")
            print(f"🔍 Event keys: {list(event.keys())}")
            
            # Extraire headers de différentes façons possibles
            headers = event.get('headers', {}) or {}
            if not headers:
                headers = event.get('multiValueHeaders', {}) or {}
            
            # Normaliser les clés de headers en minuscules
            headers_lower = {}
            if isinstance(headers, dict):
                headers_lower = {str(k).lower(): str(v) if v else '' for k, v in headers.items()}
            
            # Extraire l'origine
            origin = headers_lower.get('origin', '') or headers_lower.get('Origin', '')
            if not origin or origin.lower() in ['null', 'none', 'undefined']:
                origin = 'https://mapevent.world'
            
            allowed_origins = ['https://mapevent.world', 'http://localhost:8000', 'http://localhost:3000']
            cors_origin = origin if origin in allowed_origins else 'https://mapevent.world'
            
            print(f"🔍 Origin: {origin} -> CORS Origin: {cors_origin}")
            
            response = {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': cors_origin,
                    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization, Origin, X-Requested-With, Accept, X-Amz-Date, X-Api-Key, X-Amz-Security-Token',
                    'Access-Control-Allow-Credentials': 'true',
                    'Access-Control-Max-Age': '3600'
                },
                'body': ''
            }
            
            print(f"✅ Réponse OPTIONS: {json.dumps(response)}")
            return response
            
    except Exception as e:
        import traceback
        error_msg = f"Erreur dans OPTIONS: {str(e)}\n{traceback.format_exc()}"
        print(f"❌ {error_msg}")
        
        # Retourner quand même une réponse CORS valide même en cas d'erreur
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': 'https://mapevent.world',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, Origin, X-Requested-With, Accept, X-Amz-Date, X-Api-Key, X-Amz-Security-Token',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Max-Age': '3600'
            },
            'body': ''
        }
    
    # Pour les autres méthodes, continuer avec Flask
    try:
        # Créer l'app Flask seulement maintenant (après avoir géré OPTIONS)
        global app
        if app is None:
            try:
                app = create_app()
                print("OK: Application Flask creee")
            except Exception as e:
                print(f"❌ Erreur création app Flask: {e}")
                import traceback
                print(traceback.format_exc())
                raise
        
        # Normaliser les headers (API Gateway peut les mettre en minuscules)
        headers = event.get('headers', {}) or {}
        # Normaliser les clés de headers en minuscules pour la recherche
        headers_lower = {k.lower(): v for k, v in headers.items()}
        
        # Extraire le chemin
        path = event.get('path', '/')
        print(f"🔍 Path reçu: {path}")  # Log pour diagnostic
        if path.startswith('/default'):
            path = path.replace('/default', '', 1)
        if not path.startswith('/'):
            path = '/' + path
        print(f"🔍 Path traité: {path}")  # Log pour diagnostic
        
        method = event.get('httpMethod', 'GET')
        print(f"🔍 Méthode: {method}")  # Log pour diagnostic
        
        query_params = event.get('queryStringParameters') or {}
        body = event.get('body', '')
        print(f"🔍 Body: {body[:100] if body else 'vide'}")  # Log pour diagnostic
        
        # Utiliser Flask test client avec gestion d'erreur robuste
        print(f"🔍 Appel Flask: {method} {path}")  # Log pour diagnostic
        
        try:
            with app.test_client() as client:
                try:
                    if method == 'GET':
                        response = client.get(path, query_string=query_params)
                    elif method == 'POST':
                        # Parser le body JSON si nécessaire
                        if body and isinstance(body, str):
                            try:
                                json_data = json.loads(body)
                                response = client.post(path, json=json_data, content_type='application/json')
                            except json.JSONDecodeError:
                                # Si ce n'est pas du JSON, envoyer tel quel
                                response = client.post(path, data=body, content_type='application/json')
                        else:
                            response = client.post(path, data=body, content_type='application/json')
                    else:
                        response = client.open(path, method=method, data=body)
                    
                    print(f"🔍 Réponse Flask: {response.status_code}")  # Log pour diagnostic
                    
                    # CORRECTION CRITIQUE : Récupérer le body AVANT qu'il ne soit transformé
                    # Flask test client peut transformer les objets complexes en chaînes
                    try:
                        # Essayer de récupérer directement depuis response.data (bytes)
                        body_bytes = response.get_data(as_text=False)
                        if isinstance(body_bytes, bytes):
                            body_content = body_bytes.decode('utf-8').rstrip('\n\r')
                        else:
                            body_content = str(body_bytes).rstrip('\n\r')
                        
                        if not body_content:
                            body_content = '{}'
                        
                        print(f"🔍 Body brut récupéré ({len(body_content)} caractères): {body_content[:200]}")
                        
                        # CORRECTION CRITIQUE : Si le body contient "[dict - X items]", 
                        # c'est que Flask test client a transformé l'objet en chaîne
                        # On doit récupérer les données depuis la base de données
                        if '[dict' in body_content and 'items]' in body_content:
                            print(f"⚠️ DÉTECTION: Body contient '[dict - X items]' - Flask test client a transformé l'objet")
                            # Le handler Lambda va récupérer les données depuis la DB (voir code ci-dessous)
                        
                        # CORRECTION CRITIQUE : S'assurer que body_content est bien du JSON valide
                        # Si ce n'est pas du JSON valide, essayer de le parser et le re-sérialiser
                        try:
                            body_json = json.loads(body_content)
                            
                            # CORRECTION CRITIQUE : Vérifier si "user" est une chaîne "[dict - X items]"
                            # Si c'est le cas, récupérer les données utilisateur depuis la base de données
                            if isinstance(body_json, dict) and 'user' in body_json:
                                if isinstance(body_json['user'], str) and body_json['user'].startswith('[dict'):
                                    print(f"⚠️ ATTENTION: user est une chaîne '{body_json['user']}' au lieu d'un objet JSON")
                                    print(f"⚠️ Tentative de récupération depuis la base de données...")
                                    
                                    # CORRECTION CRITIQUE : Récupérer les données depuis la réponse Flask originale
                                    # Flask test client peut transformer les objets complexes en chaînes
                                    # On doit récupérer les données directement depuis Flask avant transformation
                                    try:
                                        # Essayer de récupérer l'email depuis le body de la requête originale
                                        request_body = event.get('body', '')
                                        user_email = ''
                                        
                                        if request_body:
                                            try:
                                                if isinstance(request_body, str):
                                                    request_data = json.loads(request_body)
                                                else:
                                                    request_data = request_body
                                                user_email = request_data.get('email', '').strip().lower()
                                                print(f"🔍 Email depuis request body: {user_email}")
                                            except:
                                                pass
                                        
                                        if not user_email:
                                            # Essayer depuis les query parameters
                                            query_params = event.get('queryStringParameters') or {}
                                            user_email = query_params.get('email', '').strip().lower()
                                            print(f"🔍 Email depuis query params: {user_email}")
                                        
                                        # Si toujours pas d'email, essayer de l'extraire depuis le path (pour les callbacks OAuth)
                                        if not user_email and 'oauth' in path.lower():
                                            # Pour les callbacks OAuth, l'email peut être dans le state ou dans un paramètre
                                            print(f"🔍 Tentative extraction email depuis path OAuth: {path}")
                                        
                                        if user_email:
                                            # Récupérer les données utilisateur depuis la base de données
                                            import psycopg2
                                            import os
                                            
                                            try:
                                                conn = psycopg2.connect(
                                                    host=os.getenv('RDS_HOST', ''),
                                                    port=os.getenv('RDS_PORT', '5432'),
                                                    database=os.getenv('RDS_DB', 'mapevent').strip(),
                                                    user=os.getenv('RDS_USER', ''),
                                                    password=os.getenv('RDS_PASSWORD', ''),
                                                    connect_timeout=5,
                                                    sslmode='require'
                                                )
                                                
                                                cursor = conn.cursor()
                                                cursor.execute("""
                                                    SELECT id, email, username, 
                                                           COALESCE(first_name, '') as first_name, 
                                                           COALESCE(last_name, '') as last_name, 
                                                           COALESCE(subscription, 'free') as subscription, 
                                                           COALESCE(role, 'user') as role,
                                                           COALESCE(avatar_emoji, '') as avatar_emoji, 
                                                           COALESCE(avatar_description, '') as avatar_description, 
                                                           COALESCE(profile_photo_url, '') as profile_photo_url,
                                                           COALESCE(postal_address, '') as postal_address, 
                                                           COALESCE(postal_city, '') as postal_city, 
                                                           COALESCE(postal_zip, '') as postal_zip, 
                                                           COALESCE(postal_country, 'CH') as postal_country,
                                                           created_at
                                                    FROM users 
                                                    WHERE email = %s
                                                    LIMIT 1
                                                """, (user_email,))
                                                
                                                user_row = cursor.fetchone()
                                                if user_row:
                                                    user_id_db, email_db, username_db, first_name_db, last_name_db, subscription_db, role_db, avatar_emoji_db, avatar_description_db, profile_photo_url_db, postal_address_db, postal_city_db, postal_zip_db, postal_country_db, created_at_db = user_row
                                                    
                                                    postal_address_obj = None
                                                    if postal_address_db and postal_address_db.strip():
                                                        postal_address_obj = {
                                                            'address': str(postal_address_db),
                                                            'city': str(postal_city_db) if postal_city_db else '',
                                                            'zip': str(postal_zip_db) if postal_zip_db else '',
                                                            'country': str(postal_country_db) if postal_country_db else 'CH'
                                                        }
                                                    
                                                    created_at_str = None
                                                    if created_at_db:
                                                        try:
                                                            if hasattr(created_at_db, 'isoformat'):
                                                                created_at_str = created_at_db.isoformat()
                                                            else:
                                                                created_at_str = str(created_at_db)
                                                        except:
                                                            created_at_str = None
                                                    
                                                    user_data_fixed = {
                                                        'id': str(user_id_db),
                                                        'email': str(email_db),
                                                        'username': str(username_db) if username_db else '',
                                                        'name': str(username_db) if username_db else '',
                                                        'firstName': str(first_name_db) if first_name_db else '',
                                                        'lastName': str(last_name_db) if last_name_db else '',
                                                        'subscription': str(subscription_db) if subscription_db else 'free',
                                                        'role': str(role_db) if role_db else 'user',
                                                        'avatar': str(avatar_emoji_db) if avatar_emoji_db else '👤',
                                                        'avatarDescription': str(avatar_description_db) if avatar_description_db else '',
                                                        'profilePhoto': str(profile_photo_url_db) if profile_photo_url_db else '',
                                                        'profile_photo_url': str(profile_photo_url_db) if profile_photo_url_db else '',
                                                        'postalAddress': postal_address_obj,
                                                        'postal_address': postal_address_obj,
                                                        'createdAt': created_at_str,
                                                        'hasPassword': True,
                                                        'hasPostalAddress': bool(postal_address_db and postal_address_db.strip())
                                                    }
                                                    
                                                    # Tester la sérialisation
                                                    test_json = json.dumps(user_data_fixed, ensure_ascii=False, default=str)
                                                    print(f"✅ user_data_fixed sérialisable ({len(test_json)} caractères)")
                                                    
                                                    body_json['user'] = user_data_fixed
                                                    print(f"✅ Données utilisateur récupérées depuis la base de données")
                                                else:
                                                    print(f"⚠️ Utilisateur non trouvé dans la base de données pour {user_email}")
                                                    body_json['user'] = {}
                                                
                                                cursor.close()
                                                conn.close()
                                            except Exception as db_conn_error:
                                                print(f"❌ Erreur connexion DB: {db_conn_error}")
                                                body_json['user'] = {}
                                        else:
                                            print(f"⚠️ Email non trouvé dans la requête, remplacement par objet vide")
                                            body_json['user'] = {}
                                    except Exception as db_error:
                                        print(f"❌ Erreur récupération depuis DB: {db_error}")
                                        import traceback
                                        print(traceback.format_exc())
                                        body_json['user'] = {}
                                        print(f"⚠️ user remplacé par un objet vide")
                            
                            # Re-sérialiser pour garantir un JSON propre
                            body_content = json.dumps(body_json, ensure_ascii=False)
                            print(f"✅ Body JSON valide et re-sérialisé ({len(body_content)} caractères)")
                        except json.JSONDecodeError as json_error:
                            print(f"⚠️ Body n'est pas du JSON valide: {json_error}")
                            print(f"⚠️ Body content (premiers 500 chars): {body_content[:500]}")
                            # Essayer de récupérer directement depuis response.data
                            try:
                                body_content = response.get_data(as_text=False)
                                if isinstance(body_content, bytes):
                                    body_content = body_content.decode('utf-8')
                                body_json = json.loads(body_content)
                                
                                # Même vérification pour la chaîne "[dict - X items]"
                                if isinstance(body_json, dict) and 'user' in body_json:
                                    if isinstance(body_json['user'], str) and body_json['user'].startswith('[dict'):
                                        print(f"⚠️ ATTENTION: user est une chaîne '{body_json['user']}' au lieu d'un objet JSON")
                                        body_json['user'] = {}
                                
                                body_content = json.dumps(body_json, ensure_ascii=False)
                                print(f"✅ Body récupéré depuis bytes et re-sérialisé")
                            except Exception as e:
                                print(f"❌ Impossible de récupérer le body: {e}")
                                body_content = '{"error": "Invalid JSON response"}'
                        
                        # Vérifier la taille du body (limite Lambda: 6MB)
                        body_size_mb = len(body_content.encode('utf-8')) / (1024 * 1024)
                        if body_size_mb > 5.5:  # Limite à 5.5MB pour être sûr
                            print(f"⚠️ Body trop volumineux: {body_size_mb:.2f}MB - Tronquage")
                            # Si c'est du JSON, essayer de le réduire
                            try:
                                body_json = json.loads(body_content)
                                # Réduire les données si possible
                                if isinstance(body_json, dict):
                                    # Supprimer les champs volumineux inutiles
                                    for key in list(body_json.keys()):
                                        if isinstance(body_json[key], (list, dict)) and len(str(body_json[key])) > 10000:
                                            body_json[key] = f"[{type(body_json[key]).__name__} - {len(body_json[key])} items]"
                                    body_content = json.dumps(body_json, ensure_ascii=False)
                            except:
                                # Si ce n'est pas du JSON, tronquer
                                body_content = body_content[:5000000]  # Limiter à ~5MB
                    except Exception as body_error:
                        print(f"⚠️ Erreur récupération body: {body_error}")
                        body_content = '{"error": "Erreur lors de la récupération de la réponse"}'
                    
                    body_size_mb = len(body_content.encode('utf-8')) / (1024 * 1024)
                    print(f"🔍 Body réponse: {body_size_mb:.2f}MB (premiers 200 chars): {body_content[:200]}")  # Log pour diagnostic
                    
                    # Retourner la réponse avec headers CORS complets
                    # Utiliser l'origine spécifique pour une meilleure sécurité
                    origin = headers_lower.get('origin', 'https://mapevent.world')
                    if not origin or origin == 'null':
                        origin = 'https://mapevent.world'
                    allowed_origins = ['https://mapevent.world', 'http://localhost:8000', 'http://localhost:3000']
                    cors_origin = origin if origin in allowed_origins else 'https://mapevent.world'
                    
                    # Vérifier la taille finale avant de retourner (limite Lambda: 6MB)
                    final_body_size = len(body_content.encode('utf-8'))
                    final_body_size_mb = final_body_size / (1024 * 1024)
                    
                    if final_body_size_mb > 5.5:  # Limite à 5.5MB pour être sûr
                        print(f"⚠️ ATTENTION: Body final trop volumineux: {final_body_size_mb:.2f}MB")
                        # Retourner une erreur plutôt qu'une réponse trop grande
                        body_content = json.dumps({
                            'error': 'Response too large',
                            'message': f'La réponse dépasse la limite de taille ({final_body_size_mb:.2f}MB > 5.5MB)',
                            'size_mb': round(final_body_size_mb, 2)
                        })
                        response.status_code = 500
                    
                    return {
                        'statusCode': response.status_code,
                        'headers': {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': cors_origin,
                            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
                            'Access-Control-Allow-Headers': 'Content-Type, Authorization, Origin, X-Requested-With, Accept, X-Amz-Date, X-Api-Key, X-Amz-Security-Token',
                            'Access-Control-Allow-Credentials': 'true',
                            'Access-Control-Max-Age': '3600'
                        },
                        'body': body_content
                    }
                except Exception as flask_error:
                    import traceback
                    print(f"❌ Erreur dans Flask test client: {flask_error}")
                    print(traceback.format_exc())
                    raise
        except Exception as client_error:
            import traceback
            print(f"❌ Erreur création/utilisation test client: {client_error}")
            print(traceback.format_exc())
            raise
            
    except Exception as e:
        import traceback
        error_type = type(e).__name__
        error_message = str(e)
        error_traceback = traceback.format_exc()
        
        print(f"❌ ERREUR CRITIQUE dans lambda_handler: {error_type}")
        print(f"❌ Message: {error_message}")
        print(f"❌ Traceback complet:\n{error_traceback}")
        
        # TOUJOURS retourner une réponse valide, même en cas d'erreur
        try:
            error_body = json.dumps({
                'error': 'Internal Server Error',
                'message': error_message[:200],  # Limiter la longueur
                'type': error_type
            })
        except:
            error_body = json.dumps({'error': 'Internal Server Error'})
        
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, Origin, X-Requested-With, Accept, X-Amz-Date, X-Api-Key, X-Amz-Security-Token',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Max-Age': '3600'
            },
            'body': error_body
        }
