"""
Lambda Handler pour MapEventAI Backend
Handler simple avec Flask test client - version ultra-simplifiée
"""

import sys
import json
from pathlib import Path

# Ajouter le chemin du backend au PYTHONPATH
backend_path = Path(__file__).parent / "backend"
backend_path_str = str(backend_path.resolve())
if backend_path_str not in sys.path:
    sys.path.insert(0, backend_path_str)

# Importer l'application Flask
try:
    from main import create_app
except ImportError as e:
    print(f"Import error: {e}")
    print(f"Python path: {sys.path}")
    raise

# Créer l'application Flask
app = create_app()

def lambda_handler(event, context):
    """
    Handler Lambda pour API Gateway
    Version ultra-simplifiée avec Flask test client
    """
    try:
        # Extraire le chemin
        path = event.get('path', '/')
        print(f"🔍 Path reçu: {path}")  # Log pour diagnostic
        if path.startswith('/default'):
            path = path.replace('/default', '', 1)
        if not path.startswith('/'):
            path = '/' + path
        print(f"🔍 Path traité: {path}")  # Log pour diagnostic
        
        method = event.get('httpMethod', 'GET')
        print(f"🔍 Méthode: {method}")  # Log pour diagnostic
        
        # Gérer OPTIONS (preflight CORS) AVANT tout
        if method == 'OPTIONS':
            print(f"✅ Requête OPTIONS détectée pour {path}")
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization, Origin, X-Requested-With',
                    'Access-Control-Max-Age': '3600'
                },
                'body': ''
            }
        
        query_params = event.get('queryStringParameters') or {}
        body = event.get('body', '')
        print(f"🔍 Body: {body[:100] if body else 'vide'}")  # Log pour diagnostic
        
        # Utiliser Flask test client
        print(f"🔍 Appel Flask: {method} {path}")  # Log pour diagnostic
        with app.test_client() as client:
            if method == 'GET':
                response = client.get(path, query_string=query_params)
            elif method == 'POST':
                response = client.post(path, data=body, content_type='application/json')
            else:
                response = client.open(path, method=method, data=body)
            
            print(f"🔍 Réponse Flask: {response.status_code}")  # Log pour diagnostic
            
            # Récupérer le body
            body_content = response.get_data(as_text=True).rstrip('\n\r')
            if not body_content:
                body_content = '[]'
            
            print(f"🔍 Body réponse: {body_content[:200]}")  # Log pour diagnostic
            
            # Retourner la réponse avec headers CORS complets
            return {
                'statusCode': response.status_code,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization, Origin, X-Requested-With',
                    'Access-Control-Max-Age': '3600'
                },
                'body': body_content
            }
            
    except Exception as e:
        import traceback
        print(f"Error: {e}")
        print(traceback.format_exc())
        
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, Origin, X-Requested-With'
            },
            'body': json.dumps({'error': 'Internal Server Error', 'message': str(e)})
        }
